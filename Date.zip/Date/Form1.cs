namespace Date
{
    public partial class Form1 : Form
    {
        string text = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string blah = textBox1.Text;
            textBox2.Text = blah;

        }

        private void label1_Click(object sender, EventArgs e)
        {


        }
    }
}